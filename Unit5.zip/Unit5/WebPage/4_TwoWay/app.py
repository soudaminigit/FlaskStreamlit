from flask import *
app = Flask(__name__)
@app.route('/')
def home():
  return render_template('login.html')

@app.route('/login',methods = ['POST'])
def login():
      uname=request.form['uname']
      passwrd=request.form['pass']
      if uname=="unit5" and passwrd=="deploy":
          text= "Welcome %s" %uname
      return render_template('success.html',txt_name=text)

app.run()