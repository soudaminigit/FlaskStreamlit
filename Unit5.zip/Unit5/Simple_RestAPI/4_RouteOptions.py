from flask import Flask
app = Flask(__name__)


# Either use decorator
@app.route('/hello')
def hello_world():
    return 'hello world'

# Or use binding function
#app.add_url_rule('/', 'hello', hello_world)


# driver function
if __name__ == '__main__':

    app.run(debug=True)
#curl http://127.0.0.1:5000/hello