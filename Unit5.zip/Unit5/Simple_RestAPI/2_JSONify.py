from flask import Flask, jsonify, request
app = Flask(__name__)

# Add routing function


@app.route('/', methods=['GET'])
# Define base function
def home():

    data = "hello world Rest API"
    return jsonify({'data': data})


# driver function
if __name__ == '__main__':

    app.run(debug=True)
