from flask import Flask, jsonify, request
app = Flask(__name__)


# Add routing function
@app.route('/', methods=['GET'])
# Define base function
def home():

    data = "hello world Rest API"
    return jsonify({'data': data})


# driver function
if __name__ == '__main__':

    #app.run()
    #app.run(debug = True)
    app.run("127.0.0.2", 4980, debug=True)
#curl http://127.0.0.2:4980