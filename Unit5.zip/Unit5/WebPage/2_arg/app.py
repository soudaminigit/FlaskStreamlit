from flask import *
app = Flask(__name__)
@app.route('/hello/<name>')
def hello_name(name):
   return 'Hello %s!' % name

@app.route('/uppname/<name>')
def uppname(name):
   return "<h1> Hello :{} </h1>".format(name.upper())

if __name__ == '__main__':
   app.run()

#curl http://127.0.0.1/hello/mini
# curl http://127.0.0.1/uppname/mini