1. To Enable the Python Environment, run the following command:
flaskenv\Scripts\activate 

2. Simple_RestAPI folder contains basic RestAPI operations.
  -> python 1_RunInMain.py -> Basic Python script to launch an API at http://127.0.0.1:5000
     Launch the REST API using the command curl http://127.0.0.1:5000
     It will display "Hello Flask"

  -> python 2_JSONify.py -> Basic Python script to return JSON response
     Use curl or launch http://127.0.0.1:5000 in the browser.
     It will display the following JSON response

	{
    		"data": "hello world Rest API"
	}

   -> python 3_RunOptions.py -> Runs the API in a different address
       Run curl http://127.0.0.2:4980
      It will display the same response as above.

   -> Python 4_RouteOptions.py -> Runs the API with a subpath
      Run curl http://127.0.0.1:5000/hello
      It will display the string "Hello World"

   -> python 5_RestAPI_Plain.py -> Takes the parameters and computes the result
      Run http://127.0.0.1:5000/square/20
      It will generate the following response:
      {
       "data": 400
       }
    -> python 6_Redirection.py -> Creates different URLs for different users.
       Run curl http://127.0.0.1/admin
       The output will be admin
3. Webpage folder contains the programs for loading webpages.
    -> Go to the folder 1_Simple
	-> templates folder contains the HTML page.
        -> Run python app.py
	Now launch the webpage in a browser using http://127.0.0.1:5000 
        It will display "Welcome to Flask" in the browser.

      -> Go to the folder 2_arg
         Run python app.py (Uses HTML tags in Python code)
         Now launch the webpage http://127.0.0.1:5000/hello/mini
         It will display "Hello mini!" in lower characters.
         Now, use the address http://127.0.0.1:5000/uppname/mini
         It will display "Hello: MINI" in bold characters.

       -> Go to the folder 3_PassVariable
           -> templates folder contains the HTML format to be displayed by default.
           -> python app.py
           -> Run http://localhost:5000
		HTML page gets displayed in Red background
	   -> Run http://localhost:5000/about
		The value "Web Development" is passed in the page and gets displayed in HTML page.

        -> Go to the folder 4_TwoWay
	   -> templates folder contains the landing page and success pages HTML
            -> Run python app.py
            -> Launch the webpage http://localhost:5000
            -> Enter random login and password: submit throws error
            -> try uname="unit5" password = "deploy"
               It will land in success page.	

        -> Go to 5_Dynamic folder
            -> templates folder contains landing page
            -> static folder contains js file
            -> Run python app.py
		Launch http://localhost:5000
		Web page gets launched with the button "Say Hello"
		It loads java script code and hence a notification gets displayed "Welcome on board"		

4. ML Deployment folder contains details for Machine Learning model deployment
	
	-> Go to 1_SalaryRegression Folder: This deploys ML model by loading the .pkl file from github repo.
	templates folder contains HTML code for landing file.
	python app.py loads the Pkl file. Takes input from text file and generates predictions.
	Launch http://localhost:5000
	
	-> Go to 2_HousePredictionModel folder -> Trains and deploys a housing prediction model.
	   The model file is present as HousePricePredict_model_1.pkl
	   Deploy the model using Deploy_a_model_as_API command
	   Launch the browser and run http://127.0.0.1:8791/HousePricePredict?area=765
           It will display the housing prediction results in JSON format.		
	