pip install scikit-learn==0.20.3
pip install jsonify