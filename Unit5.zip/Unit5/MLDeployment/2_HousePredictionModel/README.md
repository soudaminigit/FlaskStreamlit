# Deploy-Machine-Learning-Model-using-Flask
Deploy Machine Learning Model using Flask

Below are the file details:

File: Training a Model.ipynb has code for training\developing a simple linear model and saving model by using pickle

File: Deploy_a_model_as_API.py  has code for deploying the model, as of not its code is configured with local host. It should be updated with productions sever host
